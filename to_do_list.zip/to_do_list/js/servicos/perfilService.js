import { obterPerfilApi, criarPerfilApi } from "../api/perfilApi.js"
import { definirUsuarioAtual } from "../estado/usuarioState.js"
import { mostrarPerfil } from "../dom/perfilDom.js"

async function garantirPerfil(usuario) {
    let perfil = await obterPerfilApi()

    if (!perfil) {
        perfil = await criarPerfilApi(
            usuario.user_metadata.nome
        )
    }

    return perfil
}

async function inicializarUsuario(session) {
    const perfil = await garantirPerfil(session.user)

    definirUsuarioAtual({
        id: session.user.id,
        email: session.user.email,
        nome: perfil.nome
    })

    mostrarPerfil(perfil.nome)
}

export {garantirPerfil, inicializarUsuario}