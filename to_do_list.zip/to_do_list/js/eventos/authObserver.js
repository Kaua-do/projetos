import { supabaseClient } from "../config/supabase.js";
import { definirUsuarioAtual } from "../estado/usuarioState.js";

supabaseClient.auth.onAuthStateChange(async (evento, session) => {
    if (evento === "SIGNED_IN") {
        if (session) {
            if (evento === "SIGNED_IN" && !window.location.pathname.includes('perfil.html')) {
                window.location.href = './perfil.html'
            }

            return
        } 
    }

    if (evento === 'SIGNED_OUT') {
        if (!window.location.pathname.includes('login.html')) {
            window.location.href = './login.html'
        }  
    }
})
